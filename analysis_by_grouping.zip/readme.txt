remains to do:
process_word => find better verb detection algorithm

comparison between two parties
