from nltk.corpus import wordnet as wn

'''
Implemented
There are so much keywords => overfitting occurs
To minimize the effect of overfitting -> use clustering and reduce number of groups
'''

class Cluster:
    def __init__(self, c1, c2 = None):
        self.seeds = []
        if c2 == None:
            self.seeds.append(c1)
        else:
            self.seeds += c1.seeds
            self.seeds += c2.seeds

    def compare_seed(self, other_cluster):
        farthest = 1
        for s1 in self.seeds:
            for s2 in other_cluster.seeds:
                length = wn.wup_similarity(s1,s2)
                if length<farthest:
                    farthest = length

        return farthest

    def get_seed(self):
        return self.seeds



def agglomerative_clustering(seed, cluster_number):
    cluster = []
    for s in seed:
        cluster.append(Cluster(s))

    while len(cluster) > cluster_number:
        closest = 0
        c1, c2 = None, None

        for i in range(len(cluster)):
            for j in range(i+1,len(cluster)):
                length = cluster[i].compare_seed(cluster[j])
                if length > closest:
                    c1, c2 = cluster[i], cluster[j]
                    closest = length

        cluster.remove(c1)
        cluster.remove(c2)
        cluster.append(Cluster(c1,c2))

    ans = []
    for c in cluster:
        ans.append(c.get_seed())

    return ans



def convert_pos(syn_name):
    #find similar words but have different pos
    # Get all lemmas
    lemmas = [l for l in wn.synset(syn_name).lemmas()]

    # get related words
    related = [r for l in lemmas for r in l.derivationally_related_forms()]
    related += [r for l in lemmas for r in l.pertainyms()]

    # Extract the synsets from the lemmas
    new_synsets = [l.synset() for l in related]

    return new_synsets

seed = []
group_size = 7

with open('keys.txt', 'r') as f:
    for s in f.readlines():
        seed.append(s.strip())

seed = list(map(lambda x:wn.synset(x), seed))
seed_cluster = agglomerative_clustering(seed, group_size)

group = []
for cluster in seed_cluster:
    lexicons = set()
    for s in cluster:
        lexicon = set([s])
        hypos = lambda x:x.hyponyms()
        lexicon.update(set(s.closure(hypos)))
        for synset in convert_pos(s.name()):
            lexicon.update(set(synset.closure(hypos)))

        lexicons.update(lexicon)
    group.append(lexicons)

file_name = 'keyword_group_' + str(group_size) + '.txt'
with open(file_name, 'w') as f:
    for g in group:
        f.write('group\n')
        for s in g:
            f.write(s.name()+'\n')


'''
Something to do more
add verbs, adjectives to each group.
the group of economy do not contain 'economic' and 'economic' appears 47 times for all speeches.

some words are missing: ex) worker, ...

remove unrelated words: ex) x-ray_therapy.n.01
'''