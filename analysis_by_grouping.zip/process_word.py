from nltk.corpus import inaugural, stopwords, wordnet, conll2000
import nltk
from nltk.wsd import lesk
import numpy as np
from Linear_Regression import *
import matplotlib.pyplot as plt

'''
Implemented
disadvantage on word usage in past, advantage on word usage in future, negative meaning detection
sentence chunking -> find nearest verb -> check form of verb(past or future, negative or positive)
'''

PAST_DISADV = 0.1
FUTURE_ADV = 0.15

eco_rations = dict()
stop_words = set(stopwords.words('english'))

class BigramChunker(nltk.ChunkParserI):
    def __init__(self, train_sents):
        train_data = [[(t, c) for w, t, c in nltk.chunk.tree2conlltags(sent)] for sent in train_sents]
        self.tagger = nltk.BigramTagger(train_data)

    def parse(self, sentence):
        if not sentence: return None
        (words, pos) = zip(*sentence)
        chunks = self.tagger.tag(pos)
        chunk_sent = [(w, p, c) for (w, (p, c)) in zip(words, chunks)]
        return nltk.chunk.conlltags2tree(chunk_sent)

def syn_to_lem(key_synsets):
    words = set()
    for syns in key_synsets:
        s = wordnet.synset(syns)
        words.update(list(s.lemma_names()))
    return words

def clean_corpus(corpus):
    return list(map(lambda sent:list(filter(lambda word:not word in stop_words, sent)), corpus))

def concat_all(data):  # concatinate all array in a list, all elements should have same number of columns
    dat = data[0]
    for ind in range(1, len(data)):
        dat = np.concatenate((dat, data[ind]), axis=0)
    return dat

def find_node(word, position, tree):
    cnt = 0
    for i in range(len(tree)):
        phrase = tree[i]
        if type(phrase) == type((1,2)): #tuple
            if phrase[0] == word:
                cnt += 1
        else:
            for w,p in phrase:
                if w == word:
                    cnt += 1

        if cnt >= position: return i

def nearest_verb(tree, idx):
    def phrase_type(data):
        '''
        determine the label if type of data is tree or pos if type of data is tuple

        If given data is chunk, it will return name of chunk
        If given data is not chunk, it will return pos

        :param tree: nltk.tree
        :return: string
        '''
        pos = data[-1]
        if type(pos) == type('a'):
            return pos
        else:
            return data.label()

    targ_phrase = tree[idx]
    if phrase_type(targ_phrase) == 'VP':
        return idx
    elif phrase_type(targ_phrase) == 'NP' or phrase_type(targ_phrase).startswith('R'):
        a, b = 0, 0
        tree_size = len(tree)
        while idx + a < tree_size and phrase_type(tree[idx+a]) != 'VP':
            a+=1
        while idx-b >= 0 and phrase_type(tree[idx-b]) != 'VP':
            b+=1

        if idx + a == tree_size:
            if idx - b >= 0: return idx-b
        else:
            if idx - b == -1: return idx + a
            else:
                if a<b: return idx + a
                else: return idx - b

    return -1

def score_verb(tree,idx):
    score = 1
    VP = tree[idx]

    #check future or past
    for i in range(len(VP)):
        w,p = VP[i]
        if p == 'VBD' or p == 'VBN':
            score -= PAST_DISADV
            break
        if w == 'will':
            score += FUTURE_ADV
            break
        if w == 'to' and i>1:
            if VP[i-1][0] == 'going':
                if VP[i-2][0] != 'not' and VP[i-2][0] != "n't":
                    if wordnet.morphy(VP[i-2][0],wordnet.VERB) == 'be':
                        score += FUTURE_ADV
                        break
                else:
                    if i>2 and wordnet.morphy(VP[i-3][0],wordnet.VERB) == 'be':
                        score += FUTURE_ADV
                        break

    #check negative
    for w,p in VP:
        if w == 'not' or w == "n't":
            score = -score

    return score



def main():
    synset_group = []
    word_group = []
    vocab = set()
    choose_group = 5
    seed = 4
    lmda = 0.001
    text_name = "keyword_group_" + str(choose_group) + ".txt"

    f = open(text_name, 'r')

    while True:
        synset = f.readline()
        if not synset: break
        synset = synset.strip()
        if synset == 'group':
            synset_group.append(set())
        else:
            synset_group[-1].add(synset)
    f.close()

    group_size = len(synset_group)
    for g in synset_group:
        words = syn_to_lem(g)
        word_group.append(words)
        vocab.update(words)


    president_group_emp = []
    train_txt = conll2000.chunked_sents('train.txt')
    bigram_chunker = BigramChunker(train_txt)

    for fileid in inaugural.fileids():
        sents = inaugural.sents(fileid)
        Group_usage = np.zeros((1, group_size))

        for sent in sents:
            #sent = nltk.word_tokenize("He is not going to get money.")
            tagged_sent = nltk.pos_tag(sent)
            words_to_be_found = []

            for w,p in tagged_sent:
                #check if word in vocab
                if p.startswith('N'):
                    word = wordnet.morphy(w,wordnet.NOUN)
                elif p.startswith('V'):
                    word = wordnet.morphy(w,wordnet.VERB)
                elif p.startswith('J'):
                    word = wordnet.morphy(w,wordnet.ADJ)
                elif p.startswith('R'):
                    word = wordnet.morphy(w,wordnet.ADV)
                else: continue
                if not word: continue
                if not word in vocab: continue

                #multiple usage of a word
                cnt = 1
                for other_word,c,position in words_to_be_found:
                    if w == other_word: cnt = c+1

                words_to_be_found.append((w,cnt,word))

            if not words_to_be_found: continue

            #chuncking
            tree = bigram_chunker.parse(tagged_sent)

            #find location and check closest verb
            for w,c,m in words_to_be_found:
                targ_idx = find_node(w,c,tree)
                verb_idx = nearest_verb(tree,targ_idx)
                if verb_idx == -1: continue
                score = score_verb(tree, verb_idx)


                for k in range(group_size):
                    if m in word_group[k]:
                        Group_usage[0][k] += score

        president_group_emp.append((fileid,Group_usage))



    #for f in president_Synset_usage:   print(f)

    learnable = []
    for f in president_group_emp[-15:]:
        learnable.append(f[1])

    print(learnable)

    data = concat_all(learnable)
    label = np.array([[4.65,5.05,2.86,2.58,3.24, 3.14,3.82, 2.25, 3.31, 4.45,2.35,2.03,1.46,2.19,2.48]])
    label = label.T
    #best_lambda(3,data,label)
    train_acc = []
    test_acc = []
    l_list = []

    train_mean,test_mean,abs_mean = k_fold(4,data,label,random_seed = seed, lmda = lmda)
    print("training cases MSE:", train_mean)
    print("test cases MSE:",test_mean)
    print("test cases mean abs error:", abs_mean)




if __name__ == '__main__':
    main()